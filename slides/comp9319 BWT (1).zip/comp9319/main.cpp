#include <iostream>
#include "BWTDecoder.h"
#include <cstring>

using namespace std;

int main(int argc, char* argv[]) {

    if(argc == 5){
        if(!strcmp(argv[1], "-m")){
            BWTDecoder bwt = BWTDecoder(argv[2], argv[3], 1024 * 5, 0, "m");
            bwt.searchPatch(argv[2], argv[3], argv[4]);
        }
        else if(!strcmp(argv[1], "-n")){
            BWTDecoder bwt = BWTDecoder(argv[2], argv[3], 1024 * 5, 0, "n");
            bwt.searchPatch(argv[2], argv[3], argv[4]);
        }
        else if(!strcmp(argv[1], "-o")){
            BWTDecoder bwt = BWTDecoder(argv[2], argv[3], 1024 * 5, 1, "o");
            bwt.decodeBWT(argv[2], argv[3], argv[4]);
        }
    }

    if(argc == 4){
        BWTDecoder bwt = BWTDecoder(argv[1], argv[2], 1024 * 5, 0, "o");
        bwt.searchPatch(argv[1], argv[2], argv[3]);
    }


}
