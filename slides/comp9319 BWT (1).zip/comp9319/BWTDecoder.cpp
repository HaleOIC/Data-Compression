#include "BWTDecoder.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <stdio.h>
#include <cstring>


using namespace std;


BWTDecoder::BWTDecoder(string BWTpath, string IDXpath, int patch_size, int type, string param){

    this->num_patch = 0;



    this->patch_size = patch_size;

    this->BwtSize = this->calFilesize(BWTpath);

    this->C = new unsigned int [128] ();
    this->param = param;
    this->genIndexFile(BWTpath, IDXpath);

    this->genCooAndCList(BWTpath, IDXpath);
    this->num_cols = this->C[13];
    this->type = type;
    //cout<<this->num_cols<<endl;

}




long long int BWTDecoder::calFilesize(string path) {
    ifstream myfile(path);
    if(!myfile.is_open()){
        cout<<"fail open file"<<endl;
        return 0;
    }
    myfile.seekg(0, ios::end);
    long long int len = myfile.tellg();
    myfile.close();
    return len;

}

void BWTDecoder::genIndexFile(string BWTpath, string IDXpath) {
    if (existsFile(IDXpath)){
        remove(IDXpath.data());
    }
    char buf[this->patch_size];
    unsigned int charIndex[128] = {0};
    ifstream BWTfile(BWTpath);
    ofstream IDXfile(IDXpath, ios::binary);
    BWTfile.seekg(ios::beg);
    BWTfile.read(buf, this->patch_size);
    while (BWTfile.gcount() == this->patch_size){

        for(int i = 0; i < this->patch_size; i++){
            charIndex[buf[i]] ++;
        }
        for(int i = 0; i < 128; i++){
            IDXfile.write(reinterpret_cast<char *>(&charIndex[i]), sizeof(unsigned int));
        }
        this->num_patch ++;
        BWTfile.read(buf, this->patch_size);

    }

    BWTfile.close();
    IDXfile.close();
}

bool BWTDecoder::existsFile(string path) {
    if(FILE* file = fopen(path.c_str(), "r")){
        fclose(file);
        return true;
    }else{
        return false;
    }
}


void BWTDecoder::genCooAndCList(string BWTpath, string IDXpath) {
    ifstream BWTfile(BWTpath);
    ifstream IDXfile(IDXpath, ios::binary);
    unsigned int occ_tmp[128] = {0};
    if(this->num_patch >= 1 ){
        IDXfile.seekg((this->num_patch - 1) * 128 * sizeof(unsigned int), ios::beg);
        IDXfile.read(reinterpret_cast<char *> (&occ_tmp[0]), sizeof(unsigned int)*128);
    }

    BWTfile.seekg(this->num_patch * this->patch_size, ios::beg);
    char tailbuf[this->BwtSize - this->num_patch * this->patch_size];
    BWTfile.read(tailbuf, this->BwtSize - this->num_patch * this->patch_size);
    for(int i=0;i<(this->BwtSize - this->num_patch * this->patch_size); i++){
        occ_tmp[tailbuf[i]] ++;
    }
    unsigned int count=0;
    for(int i=0; i<128; i++){
        this->C[i] = count;
        count += occ_tmp[i];
    }
}


void BWTDecoder::searchPatch(string BWTpath, string IDXpath, string patch) {

    int str_len = patch.length();
    ifstream BWTfile(BWTpath);
    ifstream IDXfile(IDXpath, ios::binary);

    int idx = str_len - 1;

    int begin = this->C[patch[idx]];

    int end = this->C[patch[idx] + 1] - 1;

    while(idx >= 1 && begin <= end){
        char c = patch[idx-1];

        begin = this->C[c] + this->findC(BWTfile, IDXfile, begin-1, c);
        end = this->C[c] + this->findC(BWTfile, IDXfile, end, c) -1 ;
        idx --;
    }

    if (end < begin) {
        //cout << "no find" << endl;
        return;
    }
    if(this->type==0){

        printResultNew(BWTfile, IDXfile, begin, end, patch);
    }
    else if(this->type==1){
        this->end_point = returnindex(BWTfile, IDXfile, begin, end, patch);
    }

}


int BWTDecoder::findC(istream& BWTfile, istream& IDXfile, int index, char c) {
    unsigned int count = 0;
    int patchBegin = index / this->patch_size;
    int begin = 0;
    if(patchBegin > 0){
        begin = patchBegin * this->patch_size;
        IDXfile.seekg((patchBegin - 1) * (128 * sizeof(int)) + c * sizeof(int), ios::beg);
        IDXfile.read(reinterpret_cast<char *> (&count), sizeof(unsigned int));
        BWTfile.seekg(begin, ios::beg);
    }else{
        BWTfile.seekg(0, ios::beg);
    }
    char buffer[index-begin+1];
    BWTfile.read(buffer, index-begin+1);
    for (int i = 0; i < index-begin+1; i++) {
        if (c == buffer[i]){
            count ++;
        }
    }

    return count;


}

void BWTDecoder::printResultNew(ifstream &BTWfile, ifstream &IDXfile, int begin, int end, string patch) {

    map<int, int> m;
    int m_count = 0;
    int n_count = 0;

    int tailindex;
    for (int i = begin; i<=end; i++){
        string forward_str = this->SeachBackward(BTWfile, IDXfile, begin, end, patch, i);
        string tmp = forward_str;

        char* d = " ";
        string back_str = this->SeachForward(BTWfile, IDXfile, begin, end, patch, i, &tailindex);
        char* p = strtok(const_cast<char*>(tmp.c_str()), d);
        int col = atoi(p);

        m[col] = tailindex;
        m_count ++;
    }
    for (map<int, int>::iterator iter = m.begin(); iter != m.end(); ++iter) {

        BTWfile.seekg(iter->second, ios::beg);
        char c;
        BTWfile.read((&c), sizeof(char));

        string s = "";
        s += c;


        string out = this->SeachBackward(BTWfile, IDXfile, begin, end, s, iter->second);
        if(this->param == "o"){

            cout << out.substr(1, out.size()-2)<<endl;
        }
        n_count ++;

    }
    if(this->param == "m"){
        cout<<m_count<<endl;
    }else if(this->param == "n"){
        cout<<n_count<<endl;
    }
}

string BWTDecoder::SeachBackward(ifstream &BTWfile, ifstream &IDXfile, int begin, int end, string patch, int index) {
    string output = "";
    output += patch.at(0);
    char c = -1;
    while (c != '\n'){
        BTWfile.seekg(index, ios::beg);
        BTWfile.read(&c, sizeof(char));
        output = c + output;
        int pos = this->findC(BTWfile, IDXfile, index, c);
        index = this->C[c] + pos - 1;
    }

    return output;

}


string BWTDecoder::SeachBackwardAll(ifstream &BTWfile, ifstream &IDXfile, string patch, int* index, int max_size) {
    string output = "";
    //output += patch.at(0);
    char c = -1;
    int size = 0;

    do{


        BTWfile.seekg(*index, ios::beg);
        BTWfile.read(&c, sizeof(char));

        output = c + output;
        size += 1;
        int pos = this->findC(BTWfile, IDXfile, *index, c);
        *index = this->C[c] + pos - 1;



    } while ( (size < max_size) && (*index != this->end_point));

    //cout<<output<<endl;
    return output;

}



string BWTDecoder::SeachForward(ifstream &BTWfile, ifstream &IDXfile, int begin, int end, string patch, int index, int *tailindex) {
    string output = "";
    char c = patch.at(0);


    for(;;){

        int pos_level = index - this->C[c] + 1;
        if(pos_level<0){
            return "False";
        }
        index = this->FindCInBWT(BTWfile, IDXfile, c, pos_level);


        for (int y = 0; y < 128; y++){
            if (this->C[y] <= index && this->C[y+1]> index){
                c = y;

                break;
            }
        }

        if (c == '\n'){
            if (this->type == 0){
                *tailindex = index;
            }
            else if (this->type == 1){
                *tailindex = this->FindCInBWT(BTWfile, IDXfile, c, pos_level);
            }
            break;
        }
        else{
            output += c;
        }
    }

    return output;
}


int BWTDecoder::FindCInBWT(ifstream &BTWfile, ifstream &IDXfile, char c, int pos_level) {

    int count = 0;

    int begin = 0;
    int end = this->num_patch - 1;
    int x;

    while (begin <= end){
        int mid = (begin + end) / 2;
        IDXfile.seekg(mid * 128 * sizeof(int) + c * sizeof(int), ios::beg);
        IDXfile.read(reinterpret_cast<char *> (&count), sizeof(unsigned int));
        if(count >= pos_level){
            end = mid;
        }
        else{
            begin = mid;
        }
        if ((end - begin) == 1){
            unsigned int left = 0;
            IDXfile.seekg(begin*128*sizeof(int) + c * sizeof(unsigned int), ios::beg);
            IDXfile.read(reinterpret_cast<char *> (&left), sizeof(unsigned int));
            unsigned int right = 0;
            IDXfile.seekg(end*128*sizeof(int) + c * sizeof(unsigned int), ios::beg);
            IDXfile.read(reinterpret_cast<char *> (&right), sizeof(unsigned int));
            if (left >= pos_level){
                x = begin;
                count = 0;
            }else if(right < pos_level){
                x = end + 1;
                count = right;
            }else{
                x = end;
                count = left;
            }
            break;


        }
        else if (begin == end){
            unsigned int value = 0;
            IDXfile.seekg(begin*128*sizeof(int) + c * sizeof(unsigned int), ios::beg);
            IDXfile.read(reinterpret_cast<char *> (&value), sizeof(unsigned int));

            if (value >= pos_level){
                x = begin;
                count = 0;
                break;
            }

            else{
                x = begin+1;
                count = value;
                break;
            }



        }




    }

    BTWfile.seekg(x*this->patch_size, ios::beg);
    if (this->BwtSize >= (x+1)*this->patch_size){

        char buffer[this->patch_size];
        BTWfile.read(buffer, this->patch_size);


        for (int v = 0; v < this->patch_size; v++) {

            char symbol = buffer[v];
            if (c == symbol){
                count ++;
            }

            if (count == pos_level){
                return x * this->patch_size + v;
            }
        }

    } else {
        int buffer_size = (int)this->BwtSize - x*this->patch_size;
        char buffer[buffer_size];
        BTWfile.read(buffer,buffer_size);

        for (int v = 0; v < buffer_size; v++) {

            char symbol = buffer[v];
            if (c == symbol){
                count ++;
            }

            if (count == pos_level){
                return x*this->patch_size + v;
            }
        }

    }


    return -1;

}

void BWTDecoder::decodeBWT(string BTWpath, string IDXpath, string dstpath) {
    int WRITESIZE = 1024 * 5;
    string id_str = to_string(this->num_cols);
    this->searchPatch(BTWpath, IDXpath, id_str);
    int idx = this->end_point;
    ifstream BWTfile(BTWpath);
    ifstream IDXfile(IDXpath, ios::binary);
    ofstream DSTfile(dstpath, ios::ate);
    char c;
    BWTfile.read((&c), sizeof(char));
    string s = "";
    s += c;
    int w_num = 0;
    while(true){
        string out = this->SeachBackwardAll(BWTfile, IDXfile, s, &idx, WRITESIZE);
        DSTfile.seekp(0, ios::beg);


        if(out.size() == WRITESIZE){
//            cout<<(int)this->BwtSize - ((w_num + 1) * WRITESIZE)<<endl;
            DSTfile.seekp((int)this->BwtSize - ((w_num + 1) * WRITESIZE), ios::beg);
            DSTfile.write(out.c_str(), WRITESIZE * sizeof(char));
            w_num ++;

        }
        else{
            DSTfile.seekp(0, ios::beg);
            DSTfile.write(out.c_str(), out.size() * sizeof(char));

            DSTfile.close();
            break;
        }



    }



}

int BWTDecoder::returnindex(ifstream &BTWfile, ifstream &IDXfile, int begin, int end, string patch) {
    map<int, int> m;
    int tailindex;
    for (int i = begin; i<=end; i++){
        string forward_str = this->SeachBackward(BTWfile, IDXfile, begin, end, patch, i);
        string tmp = forward_str;

        char* d = " ";
        string back_str = this->SeachForward(BTWfile, IDXfile, begin, end, patch, i, &tailindex);
        char* p = strtok(const_cast<char*>(tmp.c_str()), d);
        int col = atoi(p);
        m[col] = tailindex;
    }
    int r;
    for (map<int, int>::iterator iter = m.begin(); iter != m.end(); ++iter) {
        r = iter->second;
    }
    return r;
}


