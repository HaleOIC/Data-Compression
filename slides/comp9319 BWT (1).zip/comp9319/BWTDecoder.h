#ifndef _BWTDECODER_H
#define _BWTDECODER_H
#include <iostream>
#include <string>
#include "BWTDecoder.h"
#include <map>
using namespace std;


class BWTDecoder{
private:
    long long int calFilesize(string path);
    void genCooAndCList(string BWTpath, string IDXpath);
    long long int BwtSize;
    int num_patch;
    int patch_size;
    int num_cols;
    int type;
    int end_point;
    string param;
    unsigned int* C;
    bool existsFile(string path);
    void genIndexFile(string BWTpath, string IDXpath);
    int findC(istream& BTWfile, istream& IDXfile, int index, char c);
    void printResultNew(ifstream& BTWfile, ifstream& IDXfile, int begin, int end, string patch);
    int returnindex(ifstream &BTWfile, ifstream &IDXfile, int begin, int end, string patch);
    string SeachBackwardAll(ifstream &BTWfile, ifstream &IDXfile, string patch, int* index, int max_size);
    string SeachBackward(ifstream &BTWfile, ifstream &IDXfile, int begin, int end, string patch, int index);
    string SeachForward(ifstream &BTWfile, ifstream &IDXfile, int begin, int end, string patch, int index, int*tailindex);
    int FindCInBWT(ifstream &BTWfile, ifstream &IDXfile, char c, int pos_level);

public:
    BWTDecoder(string BWTpath, string IDXpath, int patch_size, int type = 0, string param = "o");
    void searchPatch(string BWTpath, string IDXpath, string patch);

    void decodeBWT(string BTWpath, string IDXpath, string dstpath);

};






#endif
