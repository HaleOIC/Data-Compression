# rlebwt

Assignment for comp9319

With 100% correct rate, however, the time and space still can be optimized.